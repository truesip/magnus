# Postman-Click2Mail-SDK
Reference collection of Click2Mail APIs in Postman

1. Download the 3 json files.
2. Import them into postman (you can download Postman for free from https://www.postman.com/downloads/)
3. Set the environment to stage-user2 and click the "eye" icon
https://www.screencast.com/t/Rfrib6NS
4. Set your stage username and password
https://www.screencast.com/t/j9BgU5YU
5. To create a production environment, duplicate the stage environment
https://www.screencast.com/t/XCFo9j5oVqsh
6. Repeat steps 3 & 4 for the production environment
7. For production environment change the following to point to production
https://www.screencast.com/t/UqgRYEYQ

Here is a video which shows step-by-step how to create personalized (mail merged) mail with C2M APIs. 
https://www.loom.com/share/a82711700c0442a4acbd33a8ca2deb11
